# reels_style_video_player
Offline video player app with vertical swipe like Instagram Reels
